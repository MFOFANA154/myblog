import { Component, OnInit, Output, Input } from '@angular/core';
import  { PostlistComponent } from '../postlist/postlist.component';
import { Post } from '../models/post.model';
 

@Component({
  selector: 'app-postlistitem',
  templateUrl: './postlistitem.component.html',
  styleUrls: ['./postlistitem.component.css']
})
export class PostlistitemComponent implements OnInit {

  @Input() title:string;
  @Input() content:string;
  @Input() loveIts:number;
  @Input() created_at:Date;

  post: Post;
  dontloveIts: number = 0;

  constructor() { }

  ngOnInit() {
  }

    Like(){
    this.loveIts++;
  }

  Unlike(){
    this.dontloveIts++;
  } 

}
