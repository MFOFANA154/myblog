import { Component, Input } from '@angular/core';
import { Post } from './models/post.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
   posts = [
    new Post('La folie du vendredi après-midi',"Un collègue a soulevé un autre collègue par son calson et il s'\est déchiré", 0),
    new Post('Les pistaches', "Il est important de manger 1 un paquet de pistaches tous les 2 semaines. A consommer avec modération",0),
    new Post('Le ninja', "Un collègue arrive à apparaître et dépouille tous les paquets de nourritures et disparaît aussitôt...",0)
  ];


}
