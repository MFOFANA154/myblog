import { Component, OnInit, Output, Input } from '@angular/core';
import { Post } from '../models/post.model';

@Component({
  selector: 'app-postlist',
  templateUrl: './postlist.component.html',
  styleUrls: ['./postlist.component.css']
})
export class PostlistComponent implements OnInit {

  @Input() posts: Post[];

  constructor() { }

  ngOnInit() {
    this.posts.slice();
  }

}
